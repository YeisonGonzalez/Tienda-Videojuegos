package businesslogic;

import data.Videojuegos;
import data.indies;
import data.Arcades;
import data.estrategia;
import data.Aventura;
import data.Plataformas;
import data.Bullethell;
import data.militar;
import data.Gestion;
import data.Fantastica;
import data.historica;
import data.AAA;
import data.MundoAbierto;
import data.Deportes;
import data.Carreras;
import data.Lucha;
import data.Seccionado;
import data.Unico;
import data.Simulacion;
import data.EstiloLibre;
import data.Automovil;
import data.NoAutomovil;
import data.OneVsOne;
import data.OneVsAll;
import data.PvE;
import data.PvPRoyale;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	Plataformas plataforma1=new Plataformas();
		
	
	}

	

}
